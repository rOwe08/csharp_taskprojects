﻿using System.Drawing;
using GamePhysicsLib;

namespace JumpingPlatformGame {
	class WorldPoint
	{
		public Meter X;
        public Meter Y;
    }
    class Axis
	{ 
        public Meter LowerBound { get; set; }
        public Meter UpperBound { get; set; }
        public MeterPerSeconds Speed { get; set; }
    }
    abstract class Entity 
    {
		public virtual Color Color => Color.Black;
		public WorldPoint Location { get; set; }

		public Axis Horizontal = new Axis();
        public abstract void Update(Second deltaSeconds);
    }

	abstract class MovableEntity : Entity 
    {
        public override void Update(Second deltaSeconds)
        {
            //the left wall has been reached
            if (this.Location.X + deltaSeconds * this.Horizontal.Speed < this.Horizontal.LowerBound)
            {
                this.Location.X = this.Horizontal.LowerBound;
                this.Horizontal.Speed *= -1;
            }
            // the right wall has been reached
            if (this.Location.X + deltaSeconds * this.Horizontal.Speed > this.Horizontal.UpperBound)
            {
                this.Location.X = this.Horizontal.UpperBound;
                this.Horizontal.Speed *= -1;
            }
            this.Location.X += deltaSeconds * this.Horizontal.Speed;
        }
    }

	class MovableJumpingEntity : MovableEntity 
    {

        public Axis Vertical = new Axis();

		public override void Update(Second deltaSeconds)
		{

            //the left wall has been reached
            if (this.Location.X + deltaSeconds * this.Horizontal.Speed < this.Horizontal.LowerBound)
            {
                this.Location.X = this.Horizontal.LowerBound;
                this.Horizontal.Speed *= -1;
            }
            // the right wall has been reached
            if (this.Location.X + deltaSeconds * this.Horizontal.Speed > this.Horizontal.UpperBound)
            {
                this.Location.X = this.Horizontal.UpperBound;
                this.Horizontal.Speed *= -1;
            }
            this.Location.X += deltaSeconds * this.Horizontal.Speed;

            if (this.Vertical.Speed > 0 || this.Location.Y > this.Vertical.LowerBound)
            {
                if (this.Location.Y + deltaSeconds * this.Vertical.Speed > this.Vertical.LowerBound)
                {
                    this.Location.Y += deltaSeconds * this.Vertical.Speed;
                }
                else//the ground wall has been reached
                {
                    //for a smooth landing, we have to take care of the girls, especially before March 8th!:)
                    this.Location.Y = this.Vertical.LowerBound;                                                  
                }

                //the upper wall has been reached
                if (this.Location.Y + deltaSeconds * this.Vertical.Speed > this.Vertical.UpperBound)
                {
                    this.Location.Y = this.Vertical.UpperBound;
                    this.Vertical.Speed *= -1;
                }
            }
        }
    }

	class Joe : MovableEntity 
    {
		public override string ToString() => "Joe";
		public override Color Color => Color.Blue;
	}

	class Jack : MovableEntity 
    {
		public override string ToString() => "Jack";
		public override Color Color => Color.LightBlue;
	}

	class Jane : MovableJumpingEntity 
    {
		public override string ToString() => "Jane";
		public override Color Color => Color.Red;
	}

	class Jill : MovableJumpingEntity 
    {
		public override string ToString() => "Jill";
		public override Color Color => Color.Pink;
	}
}