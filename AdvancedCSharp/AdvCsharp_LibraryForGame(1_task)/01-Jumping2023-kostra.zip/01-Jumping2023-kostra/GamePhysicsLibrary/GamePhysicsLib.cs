﻿using System;

namespace GamePhysicsLib
{
    public class Meter
    {
        public double Value { get; set; }
        public Meter(double value)
        {
            Value = value;
        }
        public static implicit operator Meter(double d) => new Meter(d);
        public static Meter operator +(Meter m1, Meter m2) => new Meter(m1.Value + m2.Value);
        public static Meter operator -(Meter m1, Meter m2) => new Meter(m1.Value - m2.Value);
        public static Meter operator *(Meter m, double d) => new Meter(m.Value * d);
        public static Meter operator /(Meter m, double d) => new Meter(m.Value / d);
        public static MeterPerSeconds operator /(Meter m, Second s) => new MeterPerSeconds(m.Value / s.Value);
        public static double operator /(Meter m1, Meter m2) => m1.Value / m2.Value;                                     //How many times is the first value greater than the second value.
        public static bool operator >(Meter m1, Meter m2) => m1.Value > m2.Value ? true : false;
        public static bool operator <(Meter m1, Meter m2) => m1.Value < m2.Value ? true : false;
        public static bool operator >=(Meter m1, Meter m2) => m1.Value >= m2.Value ? true : false;
        public static bool operator <=(Meter m1, Meter m2) => m1.Value <= m2.Value ? true : false;
        public static bool operator ==(Meter m1, Meter m2) => m1.Value == m2.Value ? true : false;
        public static bool operator !=(Meter m1, Meter m2) => m1.Value != m2.Value ? true : false;
        public override string ToString() => $"{Value} m";
    }
    public class Second
    {
        public double Value { get; set; }
        public Second(double value)
        {
            Value = value;
        }
        public static implicit operator Second(double d) => new Second(d);
        public static Second operator +(Second s1, Second s2) => new Second(s1.Value + s2.Value);
        public static Second operator -(Second s1, Second s2) => new Second(s1.Value - s2.Value);
        public static Second operator *(Second s, double d) => new Second(s.Value * d);
        public static Second operator /(Second s, double d) => new Second(s.Value / d);
        public static Meter operator *(Second s, MeterPerSeconds mps) => new Meter(mps.Value * s.Value);
        public static double operator /(Second s1, Second s2) => s1.Value / s2.Value;                                   //How many times is the first value greater than the second value.
        public static bool operator ==(Second s1, Second s2) => s1.Value == s2.Value ? true : false;
        public static bool operator !=(Second s1, Second s2) => s1.Value != s2.Value ? true : false;
        public override string ToString() => $"{Value} s";
    }
    public class MeterPerSeconds
    {
        public double Value { get; set; }
        public MeterPerSeconds(double value)
        {
            Value = value;
        }
        public static implicit operator MeterPerSeconds(double d) => new MeterPerSeconds(d);
        public static MeterPerSeconds operator +(MeterPerSeconds mps1, MeterPerSeconds mps2) => new MeterPerSeconds(mps1.Value + mps2.Value);
        public static MeterPerSeconds operator -(MeterPerSeconds mps1, MeterPerSeconds mps2) => new MeterPerSeconds(mps1.Value - mps2.Value);
        public static MeterPerSeconds operator *(MeterPerSeconds mps, double d) => new MeterPerSeconds(mps.Value * d);
        public static Meter operator *(MeterPerSeconds mps, Second s) => new Meter(mps.Value * s.Value);
        public static double operator /(MeterPerSeconds mps1, MeterPerSeconds mps2) => mps1.Value / mps2.Value;          //How many times is the first value greater than the second value.
        public static bool operator >(MeterPerSeconds m1, double d) => m1.Value > d ? true : false;
        public static bool operator <(MeterPerSeconds m1, double d) => m1.Value < d ? true : false;
        public static bool operator >=(MeterPerSeconds m1, double d) => m1.Value >= d ? true : false;
        public static bool operator <=(MeterPerSeconds m1, double d) => m1.Value <= d ? true : false;
        public override string ToString() => $"{Value} m/s";
    }
    public static class ExtensionMetersMethods
    {
        public static Meter Meters(this double m) => new Meter(m);
        public static Meter Meters(this int m) => new Meter((double)m);
    }
    public static class ExtensionSecondsMethods
    {
        public static Second Seconds(this double m) => new Second(m);
        public static Second Seconds(this int m) => new Second((double)m);
    }
    public static class ExtensionMeterPerSecondsMethods
    {
        public static MeterPerSeconds MeterPerSeconds(this double mps) => new MeterPerSeconds(mps);
        public static MeterPerSeconds MeterPerSeconds(this int mps) => new MeterPerSeconds((double)mps);
    }
}