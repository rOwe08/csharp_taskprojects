﻿using System;
using System.Collections.Generic;

namespace MinimalisticUIFramework
{
    public class ControlInCanvas
    {
        public Canvas canvas { get; private set; }
        public Control ctrl { get; private set; }
        public ControlInCanvas(Control ctrl, Canvas canvas) 
        {
            this.canvas = canvas;
            this.ctrl = ctrl;
        }
        public Control At(float x, float y)
        {
            this.canvas.AddChild(ctrl, new Point { X = x, Y = y });
            return new Image();
        }
    }
    public abstract record class Control
    {
        public Point Location { get; private set; } = new Point { X = 0, Y = 0 };
        public ControlInCanvas PlacedIn(Canvas canvas)
        {
            return new ControlInCanvas(this, canvas);
        }
        public Control PlacedIn(StackPanel sp)
        {
            sp.AddChild(this);
            return this;
        }
        public abstract Control WithUrl(string url);
        public abstract Control WithZoomFactor(float zoomFactor);

    }

    public sealed record class Image : Control
    {
        public string Url { get; private set; } = "";
        public float ZoomFactor { get; private set; } = 1.0f;
        public override Image WithUrl(string url) 
        { 
            Url = url; 
            return this; 
        }
        public override Image WithZoomFactor(float zoomFactor) 
        { 
            ZoomFactor = zoomFactor;
            return this; 
        }
        public override string ToString() => $"Image {{ Url = \"{Url}\", ZoomFactor = {ZoomFactor} }}";
    }

    public sealed record class Label : Control
    {
        public string Text { get; private set; } = "";
        public Label WithText(string text) 
        { 
            Text = text; 
            return this; 
        }
        public override Control WithUrl(string url) => this;
        public override Control WithZoomFactor(float zoomFactor) => this;
        public override string ToString() => $"Label {{ Text = \"{Text}\" }}";
    }

    public record class Point
    {
        public float X { get; set; }
        public float Y { get; set; }
    }
    public record class CanvasItem
    {
        public Control Control { get; private set; }
        public Point Location { get; private set; }

        public CanvasItem(Control control, Point location)
        {
            Control = control;
            Location = location;
        }
    }
    public record class Canvas
    {
        private List<CanvasItem> controls = new List<CanvasItem>();

        public void AddChild(Control control, Point point)
        {
            controls.Add(new CanvasItem(control, point));
        }

        public override string ToString()
        {
            string result = "Canvas {\n";
            foreach (var canvasItem in controls)
            {
                result += $"{canvasItem.Control} at {canvasItem.Location.X}, {canvasItem.Location.Y}\n";
            }
            result += "}";
            return result;
        }
    }

    public record class StackPanel : Control
    {
        private List<Control> controls = new List<Control>();

        public void AddChild(Control control)
        {
            controls.Add(control);
        }
        public override string ToString()
        {
            string result = "StackPanel {\n";
            foreach (var control in controls)
            {
                result += $"{control} \n";
            }
            result += "}";
            return result;
        }
        public override Control WithUrl(string url) => this;
        public override Control WithZoomFactor(float zoomFactor) => this;
    }
}
