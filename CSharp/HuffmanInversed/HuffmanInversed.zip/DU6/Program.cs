﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DU6
{
    public class HuffmanTree
    {
        public ulong[] frequencies { get; set; }
        public ulong totalFreq { get; set; }
        public static Node CreateNode(FileStream fs, HuffmanTree tree)
        {
            byte[] buffer = new byte[8];
            fs.Read(buffer, 0, 7);
            int symbol = fs.ReadByte();

            if (buffer[0] % 2 != 0) // Leaf node reached
            {
                ulong freq = BitConverter.ToUInt64(buffer) >> 1;

                tree.frequencies[symbol] = freq;

                return new Node(null, null, BitConverter.ToUInt64(buffer), symbol);
            }
            else // Inner node reached
            {
                return new Node(CreateNode(fs, tree), CreateNode(fs, tree), BitConverter.ToUInt64(buffer) >> 1, null);
            }
        }
    }
    public class Node
    {
        public int? Symbol;
        public ulong Frequency;
        public Node Right;
        public Node Left;
        public bool IsLeaf;
        public Node(Node left, Node right, ulong frequency, int? symbol = null)
        {
            this.Left = left;
            this.Right = right;
            this.Frequency = frequency;
            this.Symbol = symbol;
            this.IsLeaf = (symbol != null);
        }
    }
    public class ProcessingData
    {
        public static string fileErrorMessage = "File Error";
        public static string argErrorMessage = "Argument Error";
        public static void ConvertHuff(string[] args)
        {
            byte[] expectedHeader = new byte[] { 0x7B, 0x68, 0x75, 0x7C, 0x6D, 0x7D, 0x66, 0x66 };
            byte[] zeroSequence = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

            using (FileStream fs = new FileStream(args[0], FileMode.Open))
            {
                // Read the header
                byte[] header = new byte[8];
                byte[] buffer = new byte[8];
                fs.Read(header, 0, header.Length);

                if (!header.SequenceEqual(expectedHeader))
                {
                    Console.WriteLine(fileErrorMessage);
                    return;
                }

                HuffmanTree tree = new HuffmanTree { frequencies = new ulong[256], totalFreq = 0 };
                Node rootOfTree = HuffmanTree.CreateNode(fs, tree);

                tree.totalFreq = rootOfTree.Frequency;

                fs.Read(buffer, 0, buffer.Length);
                if (!buffer.SequenceEqual(zeroSequence))
                {
                    // End of tree reached
                    Console.WriteLine(fileErrorMessage);
                    return;
                }

                string path = $"{args[0].Remove(args[0].Length - 5, 5)}";
                //string path = $"{args[0]}.test";

                ulong totalFreqTemp = tree.totalFreq;
                using (BinaryWriter bw = new BinaryWriter(File.Open(path, FileMode.OpenOrCreate)))
                {
                    // Read the encoded data and decode it
                    int b = fs.ReadByte();
                    int pos = 0;

                    while (totalFreqTemp > 0)
                    {
                        totalFreqTemp = WrByte(ref b, ref pos, rootOfTree, fs, bw, tree, totalFreqTemp);
                    }
                }
            }
        }
        private static ulong WrByte(ref int b, ref int pos, Node node, FileStream fs, BinaryWriter fw, HuffmanTree tree, ulong totalFreqTemp)
        {
            if (!node.IsLeaf)
            {
                //Inner node
                if (pos == 8)
                {
                    pos = 0;
                    b = fs.ReadByte();
                }

                pos++;

                if (b % 2 == 0)
                {
                    //Left node
                    b >>= 1;
                    totalFreqTemp = WrByte(ref b, ref pos, node.Left, fs, fw, tree, totalFreqTemp);                                            
                }
                else
                {
                    //Right node
                    b >>= 1;
                    totalFreqTemp = WrByte(ref b, ref pos, node.Right, fs, fw, tree, totalFreqTemp);                                           
                }
            }
            else
            {
                //Leaf node
                totalFreqTemp--;
                fw.Write((byte)node.Symbol);
            }
            return totalFreqTemp;
        }
        static void Main(string[] args)
        {
            try
            {
                if (args.Length == 1 && args[0].Length > 5 && args[0].Substring(args[0].Length - 5, 5) == ".huff")
                {
                    ConvertHuff(args);
                }
                else 
                {
                    Console.WriteLine(argErrorMessage);
                }
            }
            catch (Exception e) when (e is FileNotFoundException || e is UnauthorizedAccessException || e is NullReferenceException)
            {
                Console.WriteLine(fileErrorMessage);
            }
        }
    }
}