﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DU6
{
    public class HuffmanTree
    {
        public List<Node> nodes = new List<Node>();
        public Dictionary<byte?, string> DictOfData = new Dictionary<byte?, string>();
        public void Create(long[] frequencies)
        {
            nodes = ConvertDictElemToNode(frequencies);

            while (nodes.Count > 1)
            {
                (Node min, Node min1) = FindTwoMinNodes(nodes);
                Node Root = new Node();
                {
                    Root.Symbol = null;
                    Root.Frequency = min.Frequency + min1.Frequency;
                    Root.Left = min;
                    Root.Left.LeftOrRight = false;
                    Root.Right = min1;
                    Root.Right.LeftOrRight = true;
                }
                nodes.Remove(min);
                nodes.Remove(min1);
                nodes.Add(Root);
            }
            nodes[0].LeftOrRight = null;
        }
        private (Node, Node) FindTwoMinNodes(List<Node> nodes)
        {
            Node min = nodes[0];
            Node min1 = nodes[1];

            for (int i = 1; i < nodes.Count; i++)
            {
                if (min.Frequency > nodes[i].Frequency)
                {
                    min1 = min;
                    min = nodes[i];
                }
                else if (min.Frequency == nodes[i].Frequency)
                {
                    if (min.Symbol > nodes[i].Symbol)
                    {
                        min1 = min;
                        min = nodes[i];
                    }
                    else if (min1.Frequency > nodes[i].Frequency)
                    {
                        min1 = nodes[i];
                    }
                    else if (min1.Frequency == nodes[i].Frequency)
                    {
                        if (min1.Symbol > nodes[i].Symbol)
                            min1 = nodes[i];
                    }
                }
                else if (min.Frequency < nodes[i].Frequency)
                {
                    if (min1.Frequency > nodes[i].Frequency)
                    {
                        min1 = nodes[i];
                    }
                    if (min1.Frequency == nodes[i].Frequency)
                    {
                        if (min1.Symbol > nodes[i].Symbol)
                        {
                            min1 = nodes[i];
                        }
                    }
                }
            }
            return (min, min1);
        }
        public void PrintNode(Node node)
        {
            if (node.Symbol is null)
            {
                Console.Write($"{node.Frequency} ");
                PrintNode(node.Left);
                Console.Write(" ");
                PrintNode(node.Right);
            }
            else
            {
                Console.Write($"*{node.Symbol}:{node.Frequency}");
            }
        }
        public void CreateDictOfSymb(Node node, string result)
        {
            if (node.LeftOrRight is not null)
            {
                if (node.LeftOrRight is true)
                {
                    result += "1";
                }
                else
                {
                    result += "0";
                }
            }

            if (node.Symbol is null)                                  
            {
                CreateDictOfSymb(node.Left, result);
                CreateDictOfSymb(node.Right, result);
            }
            else                                                   
            {                      
                DictOfData[node.Symbol] = result;
            }
        }
        private List<Node> ConvertDictElemToNode(long[] frequencies)
        {
            List<Node> listOfNodes = new List<Node>();

            for (int i = 0; i < frequencies.Length; i++)
            {
                if (frequencies[i] != 0) listOfNodes.Add(new Node() { Symbol = (byte)i, Frequency = frequencies[i] });
            }

            return listOfNodes;
        }
    }
}