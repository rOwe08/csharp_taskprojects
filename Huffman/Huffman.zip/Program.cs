﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DU6
{
    public class Node
    {
        public byte? Symbol { get; set; }
        public long Frequency { get; set; }
        public bool? LeftOrRight { get; set; }
        public Node? Right { get; set; }
        public Node? Left { get; set; }
    }
    class ProcessingInput
    {
        public static long[] ProcessInput(string[] args)
        {
            var frequencies = new long[256];
            using (FileStream sr = new FileStream(args[0], FileMode.Open))
            {
                int c;
                while ((c = sr.ReadByte()) != -1)
                {
                    frequencies[(byte)c]++;
                }
            }
        
            return frequencies;
        }
    }
    public class ProcessingData
    {
        public static void PrintDict(Dictionary<byte, long> dict)
        {
            foreach (KeyValuePair<byte, long> symbol in dict)
            {
                Console.WriteLine(symbol);
            }
        }
        private static void PrintKodStrom(Node node, BinaryWriter writer)
        {
            if (node.Symbol is null)
            {
                long wei = node.Frequency;
                wei <<= 1;
                byte[] bytes = BitConverter.GetBytes(wei);

                writer.Write(bytes);

                PrintKodStrom(node.Left, writer);
                PrintKodStrom(node.Right, writer);
            }
            else
            {
                long wei = node.Frequency;
                wei <<= 1;
                wei++;
                byte[] bytes = BitConverter.GetBytes(wei);
                bytes[^1] = (byte)node.Symbol;
                writer.Write(bytes);
            }
        }
        private static string ReverseString(string s)
        {
            char[] chars = s.ToCharArray();
            Array.Reverse(chars);

            return new string(chars);
        }
        static void Main(string[] args)
        {
            var frequencies = new long[256];
            HuffmanTree huffmanTree = new HuffmanTree();
            try
            {
                if (args.Length == 1)
                {
                    frequencies = ProcessingInput.ProcessInput(args);
                    huffmanTree.Create(frequencies);
                    string result = "";
                    huffmanTree.CreateDictOfSymb(huffmanTree.nodes[0], result);

                    using (FileStream sr = new FileStream(args[0], FileMode.Open))
                    {
                        using (BinaryWriter writer = new BinaryWriter(File.Open($"{args[0]}.huff", FileMode.OpenOrCreate)))
                        {
                            byte[] bufferHead = new byte[] { 0x7B, 0x68, 0x75, 0x7C, 0x6D, 0x7D, 0x66, 0x66 };
                            foreach (byte b in bufferHead)                                                          //header
                            {
                                writer.Write(b);
                            }

                            PrintKodStrom(huffmanTree.nodes[0], writer);                                            //starting of encoding tree

                            int c;
                            string tempString = "";
                            string tempS = "";
                            string tempData = "";

                            for (int i = 0; i < 8; i++)                                                             //ending of encoding tree
                            {
                                writer.Write((byte)0x00);
                            }

                            while ((c = sr.ReadByte()) != -1)                                                       //starting of encoding data
                            {
                                tempS = tempString;
                                tempData = Convert.ToString(huffmanTree.DictOfData[(byte)c]);
                                tempString += tempData;
                                int lenTempString = tempString.Length;

                                if (lenTempString == 8)
                                {
                                    result = Convert.ToString(Convert.ToInt32(ReverseString(tempString), 2), 16);

                                    byte byte2 = Byte.Parse(result, System.Globalization.NumberStyles.HexNumber);
                                    writer.Write(byte2);
                                    tempString = "";
                                }
                                else while (lenTempString > 8)
                                    {
                                        int remains = lenTempString - 8;
                                        int lenData = tempData.Length;
                                        int diff = lenData - remains;
                                        tempS += tempData[0..diff];
                                        tempData = tempData.Remove(0, diff);
                                        result = Convert.ToString(Convert.ToInt32(ReverseString(tempS), 2), 16);

                                        byte byte2 = Byte.Parse(result, System.Globalization.NumberStyles.HexNumber);
                                        writer.Write(byte2);
                                        tempString = tempData;
                                        lenTempString = tempString.Length;
                                        tempS = "";
                                    }
                            }

                            if (tempString.Length > 0)                                                                      //ending of encoding data
                            {
                                result = Convert.ToString((byte)Convert.ToInt32(ReverseString(tempString), 2), 16);

                                if (result.Length == 1)
                                {
                                    string tS = $"0{result}";
                                    byte byte2 = Byte.Parse(tS, System.Globalization.NumberStyles.HexNumber);
                                    writer.Write(byte2);
                                }
                                else if (result.Length == 2)
                                {
                                    byte byte2 = Byte.Parse(result, System.Globalization.NumberStyles.HexNumber);
                                    writer.Write(byte2);
                                }
                            }
                        }
                    }
                }
                else Console.WriteLine("Argument Error");
            }

            catch (Exception e) when (e is FileNotFoundException || e is UnauthorizedAccessException || e is NullReferenceException)
            {
                Console.WriteLine("File Error");
            }
        }
    }
}